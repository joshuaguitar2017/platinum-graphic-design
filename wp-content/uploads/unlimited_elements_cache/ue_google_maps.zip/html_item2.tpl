<div class="ue-google-map__info-window">
    {% if show_info_window_image == "true" %}
	<div class="ue-google-map__info-window-img"><img  src="{% if item.place_image is empty %}{{uc_assets_url}}/no-image.png{% else %}{{item.place_image}}{% endif %}" alt="{{item.place_image_alt}}" /></div>
	{% endif %}
    
    {% if show_info_window_title == "true" %}
    <div class="ue-google-map__info-window-title">{{item.title|raw}}</div>
    {% endif %}
    
    <div class="ue-google-map__info-window-content">
      
        {% if item.place_address is empty %}
        {% else %} 
            <div class="ue-google-map__info-wrapper"> 
            <span class="ue-google-map__info-icon">{{address_icon_html|raw}}</span>   
            <span class="ue-google-map__info">{{item.place_address|raw}}</span> 
            </div>  
        {% endif %}	
      
        {% if item.place_phone is empty %}
        {% else %} 
            <div class="ue-google-map__info-wrapper"> 
            <span class="ue-google-map__info-icon">{{phone_icon_html|raw}}</span>   
            {% if phone_number_as_link == "true" %}<a class="ue-google-map__info" href="tel:{{item.place_phone|raw}}">{{item.place_phone|raw}}</a>{% endif %}
            {% if phone_number_as_link == "false" %}<span class="ue-google-map__info">{{item.place_phone|raw}}</span>{% endif %}
            </div>  
        {% endif %}
      
      {% if item.place_website is empty or item.place_website == "#" %}
        {% else %} 
            <div class="ue-google-map__info-wrapper"> 
              <span class="ue-google-map__info-icon">{{website_icon_html|raw}}</span>   
              <span class="ue-google-map__info" ><a href="{{item.place_website}}" {{item.place_website_html_attributes|raw}}>{{item.place_website_noprefix}}</a></span> 
            </div>  
        {% endif %}
      
      {% if item.place_hours is empty %}
        {% else %} 
            <div class="ue-google-map__info-wrapper"> 
            <span class="ue-google-map__info-icon">{{business_hours_icon_html|raw}}</span>   
            <span class="ue-google-map__info" >{{item.place_hours|raw}}</span> 
            </div>  
        {% endif %}	

      
      {% if item.place_content is empty %}
        {% else %} 
            <div class="ue-google-map__info-window-description">{{item.place_content|raw}}</div>
        {% endif %}	
     
      {% if show_google_map_button == "map" %}
         <a class="ue-map-dir-btn" href="http://www.google.com/maps/place/{{item.marker_latitude|raw}},{{item.marker_longitude|raw}}{% if map_type == "satellite" %}/data=!3m1!1e3{% endif %}{% if map_type == "terrain" %}/data=!3m1!4b1{% endif %}" target="{{google_map_open_link}}">{{google_map_button_text|raw}}</a>
      {% endif %}
      {% if show_google_map_button == "direction" %}
         <a class="ue-map-dir-btn" href="https://www.google.com/maps/dir/Current+Location/{{item.marker_latitude|raw}},{{item.marker_longitude|raw}}{% if map_type == "satellite" %}/data=!3m1!1e3{% endif %}{% if map_type == "terrain" %}/data=!3m1!4b1{% endif %}" target="{{google_map_open_link}}">{{google_map_button_text|raw}}</a>
      {% endif %}
      
       {% if show_learn_more_button == "true" %}
    	<div class="ue-map-learn-btn">
          {% if multisource != "uc_items" %}
            <a class="uc_more_btn {{item.dynamic_popup_link_class|raw}}" 
               {% if item.dynamic_popup_link_class|raw == " uc-open-popup" %}{{item.dynamic_popup_link_attributes|raw}}{% else %} {% if dynamic_popup_select.dynamic_popup_select_link_type != "empty" %}href="{{item.learn_more_link|raw}}"{% endif %}{% endif %}
               {{item.learn_more_link_html_attributes|raw}}>{{learn_more_button_text|raw}}
            </a>
          {% else %}
            <a class="uc_more_btn" {% if dynamic_popup_select.dynamic_popup_select_link_type != "empty" %}href="{{item.learn_more_link|raw}}"{% endif %} {{item.learn_more_link_html_attributes|raw}}>{{learn_more_button_text|raw}}</a>
          {% endif %}
    	</div>
      {% endif %}
      
    </div>
</div>