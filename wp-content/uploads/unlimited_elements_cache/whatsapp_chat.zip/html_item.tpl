<a class="ue-whatsapp-chat-agent " href="https://wa.me/{{item.whatsapp_number|raw}}" target="{{link_open_type}}" aria-label="agent">
    <div class="ue-whatsapp-chat-agent-image">
        {% if item.image is empty %}
            <img src="{{uc_assets_url}}/avatar.jpg" alt="Avatar">  
        {% else %} 
            <img src="{{item.image}}" alt="{{item.image_alt}}"> 
        {% endif %}	
        
    </div>
    <div class="ue-whatsapp-chat-agent-image-spacing"></div>
    <div class="ue-whatsapp-chat-agent-details">
      <div class="ue-whatsapp-chat-agent-details-message">{{item.default_messsage|raw}}</div>
      <div class="ue-whatsapp-chat-agent-details-subtitle">{{item.subtitle|raw}}</div>
      <div class="ue-whatsapp-chat-agent-details-title">{{item.title}}</div>
      <div class="ue-whatsapp-chat-agent-details-hours">{{item.available_hours|raw}}</div>
    </div>
  	{% if type == "agents_with_message" %}	
  	  <div class="ue-whatsapp-chat-popup-agents-message-text">{{item.default_messsage_text|raw}}</div>
      <div class="ue-whatsapp-chat-popup-agents-message-container-backBtn"><i class="fas fa-times"></i></div>
  	{% endif %}
  	
  </a>