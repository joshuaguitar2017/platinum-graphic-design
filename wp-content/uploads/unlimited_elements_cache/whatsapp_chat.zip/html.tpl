{# set uc_button_message_text = ucfunc("modify_text",send_button_message_text) #}

{% set uc_button_message_text = send_button_message_text %}

<div id="{{uc_id}}" class="ue-whatsapp-chat" data-default-open="{{open_by_default}}" data-cache-state="{{cache_state}}" data-cache-ttl="{{cache_expiry}}" data-widget-type="{{type}}" data-placement="{{placement}}"> 
    
    <div class="ue-whatsapp-chat-button-container">
    <a class="ue-whatsapp-chat-button" {% if type == "only_button" %} href="https://wa.me/{{send_button_phone|raw}}" id="{{send_button_id|raw}}" target="{{link_open_type}}"{% else %} href="javascript:void(0)"{% endif %} aria-label="chat">
      <div class="ue-whatsapp-chat-button-icon">{{icon_button_html|raw}}</div>
      {% if show_label == "true" %}
      <div class="ue-whatsapp-chat-button-label" >{{button_label|raw}}</div>
      <div class="ue-whatsapp-chat-button-label-spacing"></div>
      {% endif %}
    </a>
    
  
    <div class="ue-whatsapp-chat-popup">
       <div class="ue-whatsapp-chat-popup-title">
         <div class="ue-whatsapp-chat-popup-title-icon">{{popup_icon_html|raw}}</div>
         <div class="ue-whatsapp-chat-popup-title-icon-spacing"></div>
         <div class="ue-whatsapp-chat-popup-title-text">{{title|raw}}</div>
         <div class="ue-whatsapp-chat-popup-title-close">{{popup_close_html|raw}}</div>
       </div>
       <div class="ue-whatsapp-chat-popup-content">
         <div class="ue-whatsapp-chat-popup-message">
           <div class="ue-whatsapp-chat-popup-message-text">
           {{message_text|raw}}
           </div>
           
          
           
           {% if ( show_message_input == "true" ) and ( type != "agents" and type != "agents_with_message" ) %}
           <div class="ue-whatsapp-chat-popup-message-input">
             <textarea placeholder="{{message_placeholder|raw}}">{{uc_button_message_text|raw}}</textarea>
           </div>
           {% endif %}
           
           {% if type == "send_button" %}
           <div class="ue-whatsapp-chat-popup-message-send">
             <a href="https://wa.me/{{send_button_phone|raw}}" class="ue-whatsapp-chat-popup-message-send-link " id="{{send_button_id|raw}}" target="{{link_open_type}}" aria-label="phone">
               <div class="ue-whatsapp-chat-popup-message-send-link-icon">{{send_icon_html|raw}}</div>
               <div class="ue-whatsapp-chat-popup-message-send-link-icon-spacing"></div>
               <div class="ue-whatsapp-chat-popup-message-send-link-text">{{send_button_text|raw}}</div>
             </a>
           </div>
           {% endif %}
           
           {% if type == "agents" or type == "agents_with_message" %}
              <div class="ue-whatsapp-chat-popup-agents">
                   {{put_items()}}
              </div>
           {% endif %}
           {% if type == "agents_with_message" %}
              <div class="ue-whatsapp-chat-popup-agents-message-container">
                  <div class="ue-whatsapp-chat-popup-message-input">
                    <textarea placeholder="" class="ue-whatsapp-chat-popup-agents-message-container-text"></textarea>
                  </div>
                  <a class="ue-whatsapp-chat-popup-message-send-link" href="javascript:void(0);" id="{{send_button_id|raw}}" target="{{link_open_type}}" aria-label="message">
                  	<div class="ue-whatsapp-chat-popup-message-send-link-icon">{{send_icon_html|raw}}</div>
                    <div class="ue-whatsapp-chat-popup-message-send-link-icon-spacing"></div>
                    <div class="ue-whatsapp-chat-popup-message-send-link-text">{{send_button_text|raw}}</div>
                  </a>
              </div>
          {% endif %}
           
           
         </div>
      </div>
    </div>
   </div>
</div>