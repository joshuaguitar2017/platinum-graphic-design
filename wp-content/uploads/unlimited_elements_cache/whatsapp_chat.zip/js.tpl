jQuery(document).ready(function(){	
  function {{uc_id}}_start(){

    const container = document.querySelector('#{{uc_id}}')

    const popup = container.querySelector('.ue-whatsapp-chat-popup')
    const bounds = popup.getBoundingClientRect()
    const chatBtnHeight = container.querySelector('.ue-whatsapp-chat-button').getBoundingClientRect().height
    if ( bounds.right > window.innerWidth ) { 
      popup.style.left = `-${bounds.width - (chatBtnHeight/2)}px`
    } 

    var whatsApp = new UeWhatsAppWidget(container);
    
    {% if open_popup_on_external_link_click == "true" %}
    
      var objExternalLinks = jQuery("#ue-whatsapp-link");
      var objWidget = jQuery("#{{uc_id}}");
      var objTriggerButton = objWidget.find(".ue-whatsapp-chat-button");

      function isElementInViewport(objElement){

          var elementTop = objElement.offset().top;
          var elementBottom = elementTop + objElement.outerHeight();

          var viewportTop = jQuery(window).scrollTop();
          var viewportBottom = viewportTop + jQuery(window).height();

          return (elementBottom > viewportTop && elementTop < viewportBottom);

      }

      function scrollToSection(offsetTop){

          jQuery("html").animate({ scrollTop: offsetTop }, 400);

      }

      function onExternalWhatsappLinkClick(){

        if(isElementInViewport(objWidget) == true)    
        whatsApp.onChatBtnClick();

        if(isElementInViewport(objWidget) == false){

          var triggerButtonOffsetTop = objTriggerButton.offset().top - 100;

          scrollToSection(triggerButtonOffsetTop);

          setTimeout(function(){
              whatsApp.onChatBtnClick();
          },500)

        }


      }

      objExternalLinks.on("click", onExternalWhatsappLinkClick);
     
     {% endif %}

  }if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});